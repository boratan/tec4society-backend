from django.apps import AppConfig


class HealthcareConfig(AppConfig):
    name = 'Healthcare'
